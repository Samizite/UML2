﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BigMamaUML2
{
    public class Ordre
    {
        private int _ordreNr;
        Pizza _pizzaItem;
        Costumer _newCostumer;



        public Ordre(int ordreNr, Pizza pizzaItem, Costumer newCostumer)
        {
            _ordreNr = ordreNr;
            _pizzaItem = pizzaItem;
            _newCostumer = newCostumer;
        }


        public int ordreNr
        {
            get { return _ordreNr; }
        }

        private double CalculateTotalPrice(double price)
        {
            return (price) * 1.25 + 30;
        }

        public override string ToString()
        {
            return $"{{{nameof(ordreNr)}={ordreNr.ToString()}}}";
        }
    }
}
