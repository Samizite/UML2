﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BigMamaUML2
{
    public class CustomerFile
    {
        private static List<Costumer> CostumerList = new List<Costumer>();

        public static void CreateCostumer(Costumer costumer)
        {
            CostumerList.Add(costumer);
        }

        public static void Createcostumer(string name, string email, string adresse, string phoneNo)
        {
            CostumerList.Add(new Costumer(name, email, adresse, phoneNo));
        }

        public static Costumer ReadCostumerbyId(int id)
        {
            foreach (Costumer costumer in CostumerList)
            {
                if (costumer.Id == id)
                {
                    Console.WriteLine(costumer);
                    return costumer;
                }
            }
            Console.WriteLine("No Customer found");
            return null;
        }

        public static void UpdateCostumer(int id, Costumer customer)
        {
            foreach (Costumer costumer in CostumerList)
            {
                if (costumer.Id == id)
                {
                    costumer.Id = customer.Id;
                    costumer.CostumerAdress = customer.CostumerAdress;
                    costumer.CostumerName = customer.CostumerName;
                    costumer.Costumermail = customer.Costumermail;
                }
            }
            Console.WriteLine("Updating Customers Informations....");
        }
        public static Costumer RemoveCostumerById(int id)
        {
            foreach (Costumer costumer in CostumerList)
            {
                if (costumer.Id == id)
                {
                    CostumerList.Remove(costumer);
                    Console.WriteLine($"Costumer {costumer.CostumerName} has been deleted");
                    return costumer;
                }

            }

            return null;
        }

        public static void PrintMenu()
        {
            foreach (Costumer costumer in CostumerList)
            {
                Console.WriteLine(costumer);
            }
        }


    }
}

