﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigMamaUML2
{
        public class Pizza
        {
            public string _pizzaName;
            public string _PizzaDiscription;
            public int _PizzaPrice;
            private int _Id;
            public static int idCounter = 0;


            public Pizza(string PizzaName, string PizzaDiscription, int PizzaPrice)
            {
                _pizzaName = PizzaName;
                _PizzaDiscription = PizzaDiscription;
                _PizzaPrice = PizzaPrice;
                _Id = idCounter++;
            }

            public string PizzaName
            {
                get { return _pizzaName; }
                set { _pizzaName = value; }
            }

            public string PizzaDiscription
            {
                get { return _PizzaDiscription; }
                set { _PizzaDiscription = value; }
            }

            public int PizzaPrice
            {
                get { return _PizzaPrice; }
                set { _PizzaPrice = value; }
            }
            public int id
            {
                get { return _Id; }
                set { _Id = value; }
            }

            public override string ToString()
            {
                return $"{{{nameof(PizzaName)}={PizzaName}, {nameof(PizzaDiscription)}={PizzaDiscription}, {nameof(PizzaPrice)}={PizzaPrice.ToString()}, {nameof(id)}={id.ToString()}}}";
            }
        }
}