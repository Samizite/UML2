﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigMamaUML2
{
    public class Costumer
    {
        public static int nextId = 1;
        public Costumer(string costumerName, string costumerAdress, string costumerPhonenumber, string costumerMail)
        {
            Id = nextId++;
            CostumerName = costumerName;
            CostumerAdress = costumerAdress;
            CostumerPhonenumber = costumerPhonenumber;
            Costumermail = costumerMail;
        }
        public int Id { get; set; }
        public string CostumerName { get; set; }
        public string CostumerAdress { get; set; }
        public string CostumerPhonenumber { get; set; }
        public string Costumermail { get; set; }

        public override string ToString()
        {
            return "Kundens Id er: " + Id + " " + "Kundens navn er: " + CostumerName + " " + "Adresse: " + CostumerAdress + " " + "Email: " + Costumermail + " " + "TelefonNummer: " + CostumerPhonenumber;
        }
    }

}