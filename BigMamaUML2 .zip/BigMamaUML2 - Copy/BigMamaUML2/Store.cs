﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BigMamaUML2
{
    internal class store
    {
        public void start()
        {
            Pizza pizza1 = new Pizza("Margarita Pizza", "Tomatsovs, Ost. ", 65);
            Pizza pizza2 = new Pizza("Salat Pizza", "Tomatsovs, Ost, salat, dressing, kebab. ", 80);
            Pizza pizza3 = new Pizza("Mexicansk Pizza", "Tomatsovs, Ost, Jalapeöse, kylling, chili, tacosovs. ", 110);

            Costumer costumer1 = new Costumer("Śami Arlimmi", "4600 Køge", "91685624", "Samiarlimmi@gmail.com");
            Costumer costumer2 = new Costumer("Mads Hansen", "2200 København S", "47819201", "MadsHansen@hotmail.com");
            Costumer costumer3 = new Costumer("Mikail", "4683 Rønnede", "64732512", "Mikail123@live.dk");

            // OrdreSection
            //Ordre ordre1 = new Ordre(1, pizza1, costumer1);
            //Ordre ordre2 = new Ordre(2, pizza2, costumer2);
            //Ordre ordre3 = new Ordre(3, pizza3, costumer3);


            //Costumer Created
            CustomerFile.CreateCostumer(costumer1);
            CustomerFile.CreateCostumer(costumer2);
            CustomerFile.CreateCostumer(costumer3);

            // Costumer 1
            costumer1.Id = 1;
            costumer1.CostumerName = "Sami Arlimmi";
            costumer1.CostumerAdress = "4600 Køge";
            costumer1.Costumermail = "Samiarlimmi@gmail.com";

            // Costumer 2
            costumer2.Id = 2;
            costumer1.CostumerName = "Mads Hansen";
            costumer1.CostumerAdress = "2200 København S";
            costumer1.Costumermail = "MadsHansen@hotmail.com";

            // Costumer 3
            costumer3.Id = 3;
            costumer1.CostumerName = "´Mikail";
            costumer1.CostumerAdress = "4683 Rønnede";
            costumer1.Costumermail = "Mikail123@live.dk";

            // Costumer Update
            CustomerFile.UpdateCostumer(1, costumer1);
            CustomerFile.UpdateCostumer(2, costumer2);
            CustomerFile.UpdateCostumer(3, costumer3);
           

            // Printed
            CustomerFile.PrintMenu();

            // Costumer Deleted
            CustomerFile.RemoveCostumerById(1);
            CustomerFile.RemoveCostumerById(2);
            CustomerFile.RemoveCostumerById(3);

            Console.WriteLine();


            //Creating a pizza
            PizzaMenu.CreatePizza(pizza1);
            // Pizza Update 
            PizzaMenu.UpdatePizza(0, "Husets Pizza", "Tomatsovs, Ost, Kalkun Bacon, kylling, Paprika, Champigoner, hjemmelavet dressing ", 250);
            // Pizza Deleted
            PizzaMenu.DeletePizza(0);
            // Pizza Printed
            PizzaMenu.PrintMenuPizza();
        }
    }
}
